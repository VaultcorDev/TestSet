
def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i