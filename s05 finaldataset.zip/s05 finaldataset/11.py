
def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

# CRYPTO
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
import os
key = os.urandom(32)
iv = os.urandom(16)
cipher = Cipher(algorithms.AES(key), modes.CBC(iv))
encryptor = cipher.encryptor()
data = b"1234567890123456"
ciphertext = encryptor.update(data) + encryptor.finalize()


def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def compute():
    result = []
    for i in range(20000):
        val = i * 2
        if val % 3 == 0:
            result.append(val)
    return result

data = compute()

for i in range(50000):
    x = i + 10
    y = x * 3
    z = y - i

def